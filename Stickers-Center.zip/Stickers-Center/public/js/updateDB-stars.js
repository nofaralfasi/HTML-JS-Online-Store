const collection = firestore.collection("products");

nobutton.addEventListener("click", function () {
    collection.doc("1803-00-91").set({
        "sku": "1803-00-91",
        "imgsNum": 3,
        "imgSrc": "../images/stars/3d-yellow-stars/3d-yellow-stars1.webp",
        "name": "3D Yellow Stars",
        "category": "Stars Wallstickers",
        "price": 15,
        "discountMode": "AMOUNT",
        "discountValue": 86
    })
        .then(function () {
            console.log("Document successfully written!");
        })
        .catch(function (error) {
            console.error("Error writing document: ", error);
        });

    collection.doc("1803-01-68").set({
        "sku": "1803-01-68",
        "imgsNum": 7,
        "imgSrc": "../images/stars/blue-and-green-stars/blue-and-green-stars1.webp",
        "name": "Wall stickers glow in the dark - blue and green stars",
        "category": "Stars Wallstickers",
        "price": 15,
        "discountMode": "AMOUNT",
        "discountValue": 70
    });

    collection.doc("1905-04-93-1").set({
        "sku": "1905-04-93-1",
        "imgsNum": 12,
        "imgSrc": "../images/stars/Wall-Decals-Stars-Mix-of-150-stars/Wall-Decals-Stars-Mix-of-150-stars1.webp",
        "name": "Wall Decals Stars Mix of 150 stars",
        "category": "Stars Wallstickers",
        "price": 15,
        "discountMode": "AMOUNT",
        "discountValue": 75
    });

});
